﻿using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;

namespace Ternium
{
    /// <summary>
    /// TerniumPublicar: Clase con la estructura necesaria para armar el pedido a enviar a la RESTApi de Cobrand    
    /// </summary>        
    public class TerniumPublicar
    {
        public string CUITEmpresa { get; set; }
        public string Referencia { get; set; }
        public string Pedido { get; set; }
        public string Hash { get; set; }
    }

    /// <summary>    
    /// TerniumResult: Clase donde se recibe la respuesta de la RESTApi.     
    /// </summary>        
    public class TerniumResult
    {
        public string Status { get; set; }
        public string Message { get; set; }
    }

    class Program
    {
        static string SecretKey = "sddHHg234588"; //--> Secret key asignada por Cobrand 
        static string CUIT = "30516888241"; //--> CUIT de Ternium ...
        static string Referencia = "123456"; //--> Nro. de envío genérico para consulta de estado
        static string URI = "http://www.cobrandtest.com.ar/rest/"; //--> URL del servicio de Cobrand

        /// <summary>        
        /// Referenciar en el proyecto:
        /// System.Net.Http
        /// System.Net.Http.Formatting
        /// Newtonsoft.json (NuGuet): Install-Package Newtonsoft.Json -Version 12.0.3
        /// </summary>        

        static void Main(string[] args)
        {            
            char choice;

            for (; ; )
            {
                do
                {
                    Console.WriteLine("CobrandREST:");
                    Console.Out.WriteLine("");
                    Console.WriteLine("1. Publicar (envío con Funcion 7).");
                    Console.WriteLine("2. Consultar estado.");
                    Console.WriteLine("3. Finalizar.");                                        
                    do
                    {
                        choice = (char)Console.Read();
                    } while (choice == '\n' | choice == '\r');
                } while (choice < '1' | choice > '3' & choice != '3');

                if (choice == '3') break;

                Console.WriteLine("\n");

                switch (choice)
                {
                    case '1':

                        String PathPublicacion = @"C:/Cobrand/";

                        DirectoryInfo dirPathPublicacion = new DirectoryInfo(PathPublicacion);
                        if (!dirPathPublicacion.Exists)
                        {
                            Console.WriteLine(String.Format("El directorio de publicación {0}, no existe", PathPublicacion));
                            Console.Out.WriteLine("");                           
                        }
                        else
                        {
                            // Informo
                            Console.WriteLine(String.Format("Buscando archivos para enviar en la carpeta {0}...", PathPublicacion));
                            Console.Out.WriteLine("");

                            DirectoryInfo di = new DirectoryInfo(PathPublicacion);
                            int numXML = di.GetFiles("*.xml").Length;

                            // Recorro y publico todos los archivos de texto 
                            if (numXML > 0)
                            {
                                foreach (String archivoF7 in Directory.GetFiles(PathPublicacion, "*.xml"))
                                {
                                    // Para el úmero de envío correspondiente a cada publicación lo hacemos aleatorio.  
                                    // Se podría tomar del nombre del archivo o de otro lugar como por ejemplo un parámetro
                                    // Se utiliza para identificar el árchivo físico dentro de Cobrand.                                    

                                    Random r = new Random();
                                    int ReferenciaRandom = r.Next(0, 999999);

                                    Console.WriteLine(String.Format("Iniciando publicación del archivo {0}...", archivoF7));
                                    Console.Out.WriteLine("");

                                    //Publico en Cobrand
                                    Publicar(archivoF7, ReferenciaRandom.ToString());
                                }
                            }
                            else
                            {
                                Console.WriteLine("No se encontraron archivos a publicar.");
                                Console.Out.WriteLine("");
                            }
                        }                                                                        
                        break;
                    case '2':
                        //Busco Status de publicación en Cobrand
                        GetStatus();
                        break;                                            
                }
                Console.WriteLine();
            }  
        }


        private static void Publicar(string archivoF7, string NroEnvio)
        {
            
            Console.WriteLine("Preparando el mensaje a enviar......");
            Console.Out.WriteLine("");

            //Busco el archivo a enviar 
            byte[] fileBytes = File.ReadAllBytes(archivoF7); // Archivo a enviar
            string FileToSend = Convert.ToBase64String(fileBytes);

            //Cargo los parámetros del mensaje a enviar......
            TerniumPublicar tp = new TerniumPublicar();
            tp.CUITEmpresa = CUIT;            
            tp.Referencia = NroEnvio; 
            tp.Pedido = FileToSend;

            //Armo el hash de control....
            tp.Hash = GetMD5(tp.CUITEmpresa + tp.Referencia + tp.Pedido + SecretKey);

            try
            {
                // HTTP POST                 
                Console.WriteLine("Enviando el mensaje a Cobrand...");
                Console.Out.WriteLine("");
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(URI); 
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Invoco la API de Cobrand...
                HttpResponseMessage response = client.PostAsJsonAsync("api/ternium/publicacion", tp).Result;
                Console.Out.Write("Respuesta: ");
                if (!response.IsSuccessStatusCode)
                {
                    //Hubo error....informo.
                    Console.Out.WriteLine("ERROR: " + response.ReasonPhrase);
                }
                else
                {
                    //Ok. Muestro respuesta...
                    Console.Out.WriteLine(((int)response.StatusCode).ToString() + " - " + response.ReasonPhrase);
                    Console.Out.WriteLine("");
                    var resultado = response.Content.ReadAsAsync<TerniumResult>().Result;
                    Console.Out.WriteLine(string.Format("Estado: {0}, Detalle: {1}", resultado.Status, resultado.Message));
                }
            }
            catch (Exception err)
            {
                Console.Out.WriteLine(err.Message);
            }

            Console.Out.WriteLine("");            
        }

        private static void GetStatus()
        {            
            try
            {
                // HTTP GET
                Console.WriteLine("Consultando estado de envío genérico en Cobrand...");
                Console.Out.WriteLine("");
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(URI); 
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Invoco la API de Cobrand...
                HttpResponseMessage response = client.GetAsync("api/ternium/publicacion/"+ Referencia).Result;
                Console.Out.Write("Respuesta: ");
                if (!response.IsSuccessStatusCode)
                {
                    //Hubo error....informo.
                    Console.Out.WriteLine("ERROR: " + response.ReasonPhrase);
                }
                else
                {
                    //Ok. Muestro respuesta...
                    Console.Out.WriteLine(((int)response.StatusCode).ToString() + " - " + response.ReasonPhrase);
                    Console.Out.WriteLine("");
                    var resultado = response.Content.ReadAsAsync<TerniumResult>().Result;
                    Console.Out.WriteLine(string.Format("Estado: {0}, Detalle: {1}", resultado.Status, resultado.Message));
                }
            }
            catch (Exception err)
            {
                Console.Out.WriteLine(err.Message);
            }

            Console.Out.WriteLine("");            
        }

        public static String GetMD5(string str)
        {
            MD5 md5 = MD5CryptoServiceProvider.Create();
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] stream = null;
            StringBuilder sb = new StringBuilder();
            stream = md5.ComputeHash(encoding.GetBytes(str));
            for (int i = 0; i < stream.Length; i++) sb.AppendFormat("{0:x2}", stream[i]);
            return sb.ToString();
        }        
    }    
}
